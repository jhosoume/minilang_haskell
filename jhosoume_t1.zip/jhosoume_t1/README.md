Juliana Mayumi Hosoume 17/0003078

Haskell -> arquivos .hs contendo a implementação da linguagem.
TF -> arquivo PDF com as transformações realizadas e os arquivos log.
